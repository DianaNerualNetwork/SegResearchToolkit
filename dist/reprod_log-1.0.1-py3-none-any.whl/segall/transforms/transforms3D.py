
from typing import List, Tuple, Union, Callable
import math
import random
import numpy as np
import numbers
import collections

from segall.cvlibs import manager
from segall.transforms import functional as F


@manager.TRANSFORMS.add_component
class MedicalCompose:
    """
    Do transformation on input data with corresponding pre-processing and augmentation operations.
    The shape of input data to all operations is [height, width, channels].
    Args:
        transforms (list): A list contains data pre-processing or augmentation. Empty list means only reading images, no transformation.
    Raises:
        TypeError: When 'transforms' is not a list.
        ValueError: when the length of 'transforms' is less than 1.
    """

    def __init__(self, transforms, isnhwd=True, use_std=False):
        if not isinstance(transforms, list):
            raise TypeError('The transforms must be a list!')
        self.transforms = transforms
        self.isnhwd = isnhwd
        self.use_std = use_std

    def __call__(self, im, label=None, isnhwd=True):
        """
        Args:
            im (str|np.ndarray): It is either image path or image object.
            label (str|np.ndarray): It is either label path or label ndarray.
            isnhwd: Data format。
        Returns:
            (tuple). A tuple including image, image info, and label after transformation.
        """
        if isinstance(im, str):
            im = np.load(im)
        mean = np.mean(im)
        std = np.std(im)
        if isinstance(label, str):
            label = np.load(label)
        if im is None:
            raise ValueError('Cannot read the image file {}!'.format(im))

        for op in self.transforms:
            outputs = op(im, label)
            im = outputs[0]
            if len(outputs) == 2:
                label = outputs[1]
        if self.isnhwd:
            im = np.expand_dims(im, axis=0)

        if (not self.use_std) and im.max() > 0:
            im = im / im.max()
        else:
            im = (im - mean) / (std + 1e-10)

        return (im, label)