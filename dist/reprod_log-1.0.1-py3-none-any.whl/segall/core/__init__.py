from .train import train
from .val import evaluate
from .infer import *
from .predict import *